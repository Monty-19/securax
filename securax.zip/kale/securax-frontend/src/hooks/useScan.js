import { useCallback, useState } from 'react'
import api from '../lib/api'

export function useScan(type) {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState(null)

  const scan = useCallback(
    async (value) => {
      setIsLoading(true)
      setError(null)

      try {
        let response

        if (type === 'screenshot') {
          const formData = new FormData()
          formData.append('file', value)
          response = await api.post('/api/scan/screenshot', formData, {
            headers: { 'Content-Type': 'multipart/form-data' },
          })
        } else if (type === 'text') {
          response = await api.post('/api/scan/text', { input_value: value })
        } else {
          response = await api.post('/api/scan/url', { input_value: value })
        }

        const result = response.data

        try {
          await api.post('/api/history', {
            input_value: typeof value === 'string' ? value : value?.name || 'uploaded_image',
            scan_type: type?.toUpperCase?.() || 'URL',
            is_threat: result?.is_threat,
            confidence_score: result?.confidence_score,
            threat_type: result?.threat_type ?? null,
            reasons: result?.reasons ?? [],
            ocr_text: result?.ocr_text ?? null,
            created_at: new Date().toISOString(),
            result,
          })
        } catch {
          // Do not block successful scan result if history persistence fails.
        }

        return result
      } catch (scanError) {
        setError(scanError)
        throw scanError
      } finally {
        setIsLoading(false)
      }
    },
    [type],
  )

  return { scan, isLoading, error }
}
