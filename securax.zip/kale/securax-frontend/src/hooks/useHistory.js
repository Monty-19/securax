import { useMemo } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import api from '../lib/api'

const fetchHistory = async () => {
  const { data } = await api.get('/api/history')
  return Array.isArray(data) ? data : []
}

export function useHistory() {
  const query = useQuery({
    queryKey: ['history'],
    queryFn: fetchHistory,
    retry: 1,
  })

  const scans = useMemo(() => (Array.isArray(query.data) ? query.data : []), [query.data])

  const threatsToday = useMemo(() => {
    const now = new Date()
    return scans.filter((scan) => {
      if (!scan?.is_threat || !scan?.created_at) {
        return false
      }

      const created = new Date(scan.created_at)
      if (Number.isNaN(created.getTime())) {
        return false
      }

      return (
        created.getFullYear() === now.getFullYear() &&
        created.getMonth() === now.getMonth() &&
        created.getDate() === now.getDate()
      )
    }).length
  }, [scans])

  const totalScans = scans.length
  const safeCount = scans.filter((scan) => !scan?.is_threat).length

  return {
    scans,
    isLoading: query.isLoading,
    threatsToday,
    totalScans,
    safeCount,
  }
}

export function useAddScan() {
  const queryClient = useQueryClient()

  return useMutation({
    mutationFn: async (payload) => {
      const { data } = await api.post('/api/history', payload)
      return data
    },
    onSettled: async () => {
      await queryClient.invalidateQueries({ queryKey: ['history'] })
    },
  })
}
