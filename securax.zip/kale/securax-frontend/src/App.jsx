import { BrowserRouter, Route, Routes } from 'react-router-dom'
import ErrorBoundary from './components/ErrorBoundary'
import Splash from './pages/Splash'
import SignIn from './pages/SignIn'
import Dashboard from './pages/Dashboard'
import ScreenshotScanner from './pages/ScreenshotScanner'
import ScanLoading from './pages/ScanLoading'
import ScanResult from './pages/ScanResult'
import History from './pages/History'

function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Splash />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/scan/screenshot" element={<ScreenshotScanner />} />
          <Route path="/scan/loading" element={<ScanLoading />} />
          <Route path="/scan/result" element={<ScanResult />} />
          <Route path="/history" element={<History />} />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  )
}

export default App
