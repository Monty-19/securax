import { useEffect, useMemo } from 'react'
import { motion } from 'framer-motion'
import { Link, useLocation, useNavigate } from 'react-router-dom'

function normalizeConfidence(value) {
  const parsed = Number(value)
  if (Number.isNaN(parsed)) return 0
  const percent = parsed <= 1 ? parsed * 100 : parsed
  return Math.max(0, Math.min(100, Math.round(percent)))
}

function mapReasonMeta(reason) {
  const lower = String(reason || '').toLowerCase()

  if (/(domain|url|site|link)/.test(lower)) {
    return {
      icon: 'public_off',
      title: 'Domain Reputation Risk',
      detail: reason,
    }
  }

  if (/(urgent|immediate|asap|action required|warning)/.test(lower)) {
    return {
      icon: 'priority_high',
      title: 'Urgency Manipulation',
      detail: reason,
    }
  }

  if (/(sender|identity|impersonat|from|account team)/.test(lower)) {
    return {
      icon: 'person_off',
      title: 'Sender Identity Mismatch',
      detail: reason,
    }
  }

  if (/(credential|password|login|verify|otp|code)/.test(lower)) {
    return {
      icon: 'link_off',
      title: 'Credential Harvesting Pattern',
      detail: reason,
    }
  }

  return {
    icon: 'warning',
    title: 'Suspicious Signal Detected',
    detail: reason,
  }
}

export default function ScanResult() {
  const { state } = useLocation()
  const navigate = useNavigate()

  const result = useMemo(() => state?.result ?? state ?? null, [state])

  useEffect(() => {
    if (!result) {
      navigate('/dashboard', { replace: true })
    }
  }, [navigate, result])

  if (!result) {
    return null
  }

  const isThreat = Boolean(result.is_threat)
  const confidencePercent = normalizeConfidence(result.confidence_score)
  const reasons = Array.isArray(result.reasons) ? result.reasons : []

  return (
    <main className="min-h-screen bg-surface pb-10">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-outline-variant/30 bg-surface/80 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex w-full max-w-md items-center justify-between">
          <Link
            to="/dashboard"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-surface-container text-on-surface"
            aria-label="Back to dashboard"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </Link>
          <h1 className="font-headline text-lg font-bold text-on-surface">Scan Result</h1>
          <div className="h-9 w-9" />
        </div>
      </header>

      <section className="mx-auto flex w-full max-w-md flex-col gap-8 px-6 pb-8 pt-20">
        <section className="flex flex-col items-center pb-4 pt-8 text-center">
          <motion.div
            initial={{ scale: 0.5 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.55, ease: [0.2, 0.9, 0.3, 1.25] }}
            className="flex h-40 w-40 items-center justify-center"
            style={{
              borderRadius: '40% 60% 70% 30% / 40% 50% 60% 50%',
              background: isThreat
                ? 'linear-gradient(135deg, #ba1a1a, #ffdad6)'
                : 'linear-gradient(135deg, #006e1c, #4caf50)',
              boxShadow: isThreat
                ? '0 10px 40px rgba(186,26,26,0.2)'
                : '0 10px 40px rgba(0,110,28,0.24)',
            }}
          >
            <span
              className="material-symbols-outlined text-[56px] leading-none text-white"
              style={{ fontVariationSettings: "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 48" }}
            >
              {isThreat ? 'warning' : 'check_circle'}
            </span>
          </motion.div>

          <h2
            className={`mt-5 font-headline text-[2rem] font-extrabold tracking-tight ${
              isThreat ? 'text-error' : 'text-tertiary'
            }`}
          >
            {isThreat ? 'THREAT DETECTED' : 'ALL CLEAR'}
          </h2>

          <div
            className={`mt-4 inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold ${
              isThreat ? 'bg-error-container text-error' : 'bg-tertiary-container/20 text-tertiary'
            }`}
          >
            <span className="material-symbols-outlined text-base">policy</span>
            {confidencePercent}% Confidence Score
          </div>
        </section>

        <section className="overflow-hidden rounded-lg border border-outline-variant/30 bg-surface-container-lowest">
          <div className="flex">
            <div className={`w-2 ${isThreat ? 'bg-error' : 'bg-tertiary'}`} />
            <div className="flex-1 p-5">
              <div className="flex items-center gap-2">
                <span className={`material-symbols-outlined ${isThreat ? 'text-error' : 'text-tertiary'}`}>
                  {isThreat ? 'mark_email_read' : 'verified_user'}
                </span>
                <h3 className="font-headline text-lg font-bold text-on-surface">Analysis Summary</h3>
              </div>
              <p className="mt-2 text-sm leading-6 text-on-surface-variant">
                {isThreat
                  ? 'Potential phishing indicators were detected in this content. Avoid opening links or sharing credentials before verifying the source.'
                  : 'No strong phishing signals were detected in this scan. Continue with normal caution and verify sensitive requests if needed.'}
              </p>

              {(result.input_value || result.scan_type) ? (
                <p className="mt-2 text-xs text-on-surface-variant">
                  {result.scan_type ? `Type: ${result.scan_type}` : ''}
                  {result.scan_type && result.input_value ? ' • ' : ''}
                  {result.input_value ? `Input: ${String(result.input_value).slice(0, 80)}` : ''}
                </p>
              ) : null}
            </div>
          </div>
        </section>

        {isThreat ? (
          <section>
            <h3 className="px-2 font-headline text-lg font-bold text-on-surface">Why this was flagged</h3>
            <article className="mt-3 rounded-lg bg-surface-container-low p-6">
              <ul className="space-y-4">
                {reasons.map((reason, index) => {
                  const meta = mapReasonMeta(reason)
                  return (
                    <li key={`${reason}-${index}`} className="flex items-start gap-3">
                      <span className="material-symbols-outlined mt-0.5 text-error">{meta.icon}</span>
                      <div>
                        <p className="text-sm font-semibold text-on-surface">{meta.title}</p>
                        <p className="mt-1 text-sm leading-6 text-on-surface-variant">{meta.detail}</p>
                      </div>
                    </li>
                  )
                })}
              </ul>
            </article>
          </section>
        ) : (
          <section>
            <h3 className="px-2 font-headline text-lg font-bold text-on-surface">Why this is safe</h3>
            <article className="mt-3 rounded-lg bg-surface-container-low p-6">
              <ul className="space-y-3">
                {['Domain verified', 'No suspicious patterns', 'Sender identity confirmed'].map((item) => (
                  <li key={item} className="flex items-center gap-3">
                    <span className="material-symbols-outlined text-tertiary">check_circle</span>
                    <span className="text-sm font-medium text-on-surface">{item}</span>
                  </li>
                ))}
              </ul>
            </article>
          </section>
        )}

        {result.ocr_text ? (
          <section className="rounded-lg border border-outline-variant/25 bg-surface-container-lowest p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.08em] text-on-surface-variant">Detected OCR Text</p>
            <p className="mt-2 text-sm leading-6 text-on-surface-variant">{result.ocr_text}</p>
          </section>
        ) : null}

        <section className="space-y-3">
          {isThreat ? (
            <>
              <button
                type="button"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-error px-5 py-3.5 text-sm font-semibold text-white shadow-[0_10px_24px_rgba(186,26,26,0.28)]"
              >
                <span className="material-symbols-outlined text-base">block</span>
                Report & Block
              </button>
              <button
                type="button"
                className="inline-flex w-full items-center justify-center gap-2 rounded-full border border-outline-variant bg-transparent px-5 py-3.5 text-sm font-semibold text-on-surface"
              >
                <span className="material-symbols-outlined text-base">health_and_safety</span>
                Open in Safe Mode
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                className="primary-gradient inline-flex w-full items-center justify-center gap-2 rounded-full px-5 py-3.5 text-sm font-semibold text-on-primary"
              >
                <span className="material-symbols-outlined text-base">open_in_new</span>
                Open Link
              </button>
              <Link
                to="/dashboard"
                className="inline-flex w-full items-center justify-center rounded-full border border-outline-variant bg-transparent px-5 py-3.5 text-sm font-semibold text-on-surface"
              >
                Scan Another
              </Link>
            </>
          )}
        </section>

        <footer className="flex items-center justify-center gap-1.5 py-1 text-xs text-on-surface-variant">
          <span className="material-symbols-outlined text-sm">verified</span>
          SecuraX AI analysis
        </footer>
      </section>
    </main>
  )
}
