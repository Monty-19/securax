import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import BottomNav from '../components/BottomNav'
import TopBar from '../components/TopBar'
import { useHistory } from '../hooks/useHistory'

function formatTimeAgo(value) {
  if (!value) return 'Just now'
  const parsed = new Date(value)
  if (Number.isNaN(parsed.getTime())) return 'Just now'

  const diff = Date.now() - parsed.getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  const days = Math.floor(hrs / 24)
  return `${days}d ago`
}

function toScanTypeBadge(scanType) {
  const normalized = String(scanType || '').toLowerCase()
  if (normalized === 'screenshot' || normalized === 'img' || normalized === 'image') return 'IMG'
  if (normalized === 'text') return 'TEXT'
  return 'URL'
}

function truncate(value, limit = 40) {
  if (!value) return 'Untitled scan'
  return value.length > limit ? `${value.slice(0, limit)}...` : value
}

export default function History() {
  const navigate = useNavigate()
  const { scans, isLoading, totalScans, threatsToday, safeCount } = useHistory()
  const [filter, setFilter] = useState('all')

  const filteredScans = useMemo(() => {
    if (filter === 'threats') {
      return scans.filter((scan) => Boolean(scan?.is_threat))
    }
    if (filter === 'safe') {
      return scans.filter((scan) => !scan?.is_threat)
    }
    return scans
  }, [filter, scans])

  const handleOpenResult = (scan) => {
    navigate('/scan/result', {
      state: {
        is_threat: Boolean(scan?.is_threat),
        confidence_score: scan?.confidence_score ?? 0,
        threat_type: scan?.threat_type ?? null,
        reasons: Array.isArray(scan?.reasons)
          ? scan.reasons
          : typeof scan?.reasons === 'string'
            ? JSON.parse(scan.reasons || '[]')
            : [],
        ocr_text: scan?.ocr_text ?? null,
        input_value: scan?.input_value ?? '',
        scan_type: scan?.scan_type ?? '',
      },
    })
  }

  return (
    <main className="min-h-screen bg-surface pb-28">
      <TopBar title="Scan History" />

      <section className="mx-auto w-full max-w-4xl px-4 pb-8 pt-20">
        <div className="grid grid-cols-3 gap-3">
          <article className="rounded-lg bg-surface-container-lowest p-4">
            <div className="mb-2 inline-flex rounded-full bg-secondary/15 p-2 text-secondary">
              <span className="material-symbols-outlined">counter_1</span>
            </div>
            <p className="font-headline text-[2rem] font-bold leading-none text-on-surface">{totalScans}</p>
            <p className="mt-2 text-xs text-on-surface-variant">Total Scans</p>
          </article>

          <article className="rounded-lg bg-surface-container-lowest p-4">
            <div className="mb-2 inline-flex rounded-full bg-error/10 p-2 text-error">
              <span className="material-symbols-outlined">warning</span>
            </div>
            <p className="font-headline text-[2rem] font-bold leading-none text-on-surface">{threatsToday}</p>
            <p className="mt-2 text-xs text-on-surface-variant">Threats Blocked</p>
          </article>

          <article className="rounded-lg bg-surface-container-lowest p-4">
            <div className="mb-2 inline-flex rounded-full bg-tertiary/15 p-2 text-tertiary">
              <span className="material-symbols-outlined">check_circle</span>
            </div>
            <p className="font-headline text-[2rem] font-bold leading-none text-on-surface">{safeCount}</p>
            <p className="mt-2 text-xs text-on-surface-variant">Safe Scans</p>
          </article>
        </div>

        <div className="mt-6 flex items-center gap-2">
          {[
            { key: 'all', label: 'All' },
            { key: 'threats', label: 'Threats' },
            { key: 'safe', label: 'Safe' },
          ].map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setFilter(item.key)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                filter === item.key
                  ? 'bg-primary text-on-primary'
                  : 'bg-surface-container-low text-on-surface-variant hover:text-primary'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        <div className="mt-5 space-y-3">
          {isLoading ? (
            <>
              {[1, 2, 3].map((row) => (
                <div key={row} className="h-16 animate-pulse rounded-xl bg-surface-container-low" />
              ))}
            </>
          ) : null}

          {!isLoading && filteredScans.length > 0
            ? filteredScans.map((scan, index) => {
                const isThreat = Boolean(scan?.is_threat)
                const icon = isThreat ? 'warning' : 'check_circle'
                const iconColor = isThreat ? 'text-error' : 'text-tertiary'
                const badgeClass = isThreat
                  ? 'bg-error-container text-on-error-container'
                  : 'bg-tertiary-container text-on-tertiary-container'

                return (
                  <button
                    key={scan?.id ?? `${scan?.input_value || 'scan'}-${index}`}
                    type="button"
                    onClick={() => handleOpenResult(scan)}
                    className="glass-panel flex w-full items-center justify-between gap-3 rounded-lg border border-outline-variant/40 p-4 text-left"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <span className={`material-symbols-outlined ${iconColor}`}>{icon}</span>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-on-surface">{truncate(scan?.input_value, 40)}</p>
                        <div className="mt-1 flex items-center gap-2 text-xs text-on-surface-variant">
                          <span className="rounded-full bg-surface-container px-2 py-0.5 font-semibold text-on-surface-variant">
                            {toScanTypeBadge(scan?.scan_type)}
                          </span>
                          <span>{formatTimeAgo(scan?.created_at)}</span>
                        </div>
                      </div>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${badgeClass}`}>
                      {isThreat ? 'Threat Blocked' : 'Safe'}
                    </span>
                  </button>
                )
              })
            : null}

          {!isLoading && filteredScans.length === 0 ? (
            <article className="rounded-xl border border-dashed border-outline-variant/40 bg-surface-container-low px-5 py-8 text-center">
              <span className="material-symbols-outlined text-4xl text-on-surface-variant">search_off</span>
              <p className="mt-2 font-headline text-lg font-semibold text-on-surface">No scans yet</p>
              <p className="mt-1 text-sm text-on-surface-variant">Start scanning to build your history</p>
            </article>
          ) : null}
        </div>
      </section>

      <BottomNav active="history" />
    </main>
  )
}
