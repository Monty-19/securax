import { useCallback, useEffect, useMemo, useState } from 'react'
import { useDropzone } from 'react-dropzone'
import { Link, useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import BottomNav from '../components/BottomNav'
import api from '../lib/api'

const suspiciousPattern = /(https?:\/\/[^\s]+|\b(?:b4nk|l0gin|acc0unt|ver1fy|p4ssw0rd)\b)/gi

function renderHighlightedText(text) {
  if (!text) return null

  const parts = text.split(suspiciousPattern)

  return parts.map((part, index) => {
    if (!part) return null

    const isSuspicious = suspiciousPattern.test(part)
    suspiciousPattern.lastIndex = 0

    if (!isSuspicious) {
      return <span key={`${part}-${index}`}>{part}</span>
    }

    return (
      <span
        key={`${part}-${index}`}
        className="rounded-md bg-error-container px-1.5 py-0.5 font-medium text-error"
      >
        {part}
      </span>
    )
  })
}

export default function ScreenshotScanner() {
  const navigate = useNavigate()
  const [file, setFile] = useState(null)
  const [previewUrl, setPreviewUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [ocrText, setOcrText] = useState('')

  useEffect(() => {
    if (!file) {
      setPreviewUrl('')
      return
    }

    const url = URL.createObjectURL(file)
    setPreviewUrl(url)

    return () => {
      URL.revokeObjectURL(url)
    }
  }, [file])

  const onDrop = useCallback(
    (acceptedFiles) => {
      const selectedFile = acceptedFiles[0]
      if (!selectedFile) {
        return
      }

      setFile(selectedFile)
      setResult(null)
      setOcrText('')
    },
    [],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    maxFiles: 1,
    accept: { 'image/*': [] },
  })

  const hasResult = Boolean(result)

  const handleAnalyze = async () => {
    if (!file) {
      toast.error('Please upload a screenshot first.')
      return
    }

    setLoading(true)

    try {
      const formData = new FormData()
      formData.append('file', file)

      const { data } = await api.post('/api/scan/screenshot', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })

      setResult(data)
      setOcrText(data?.ocr_text || data?.ocrText || '')
      navigate('/scan/result', { state: { result: data } })
    } catch {
      toast.error('Analysis failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const highlightedOcr = useMemo(() => renderHighlightedText(ocrText), [ocrText])

  return (
    <main className="min-h-screen bg-surface pb-28">
      <header className="glass-nav fixed inset-x-0 top-0 z-40 border-b border-outline-variant/40 px-4 py-3">
        <div className="mx-auto flex w-full max-w-screen-md items-center gap-3">
          <Link
            to="/dashboard"
            className="flex h-9 w-9 items-center justify-center rounded-full bg-primary/10 text-primary"
            aria-label="Back to dashboard"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </Link>
          <h1 className="font-headline text-lg font-bold text-primary">Screenshot Scanner</h1>
        </div>
      </header>

      <section className="mx-auto w-full max-w-screen-md px-6 py-8 pt-24">
        <div className="text-center">
          <h2 className="font-headline text-[1.75rem] font-extrabold text-on-surface">Scan Screenshot</h2>
          <p className="mt-2 text-sm text-on-surface-variant">
            Detect phishing from images instantly using AI analysis.
          </p>
        </div>

        <div className="mb-10 mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
          <div
            {...getRootProps()}
            className={`group relative h-64 cursor-pointer overflow-hidden rounded-lg border-2 border-dashed transition ${
              isDragActive
                ? 'border-primary bg-surface-container'
                : 'border-outline-variant/30 bg-surface-container-low hover:border-primary/50'
            }`}
          >
            <input {...getInputProps()} />

            {previewUrl ? (
              <img src={previewUrl} alt="Selected screenshot preview" className="h-full w-full object-cover" />
            ) : (
              <div className="flex h-full flex-col items-center justify-center px-6 text-center">
                <span
                  className="material-symbols-outlined text-[40px] leading-none text-primary"
                  style={{ fontVariationSettings: "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 48" }}
                >
                  add_photo_alternate
                </span>
                <p className="mt-3 font-headline text-base font-semibold text-on-surface">Upload or Capture Screenshot</p>
                <p className="mt-1 text-sm text-on-surface-variant">Tap to open gallery or camera</p>
              </div>
            )}
          </div>

          <div className="flex flex-col gap-6">
            {file ? (
              <article className="glass-panel flex h-[115px] items-center gap-3 rounded-lg border border-outline-variant/35 p-3">
                {previewUrl ? (
                  <img src={previewUrl} alt="Thumbnail" className="h-16 w-16 rounded-md object-cover" />
                ) : (
                  <div className="h-16 w-16 rounded-md bg-surface-container" />
                )}
                <div className="min-w-0">
                  <p className="truncate font-headline text-sm font-semibold text-on-surface">{file.name}</p>
                  <p className="mt-1 text-xs text-primary">Ready to analyze</p>
                </div>
              </article>
            ) : null}

            <article className="glass-panel min-h-[143px] rounded-lg border border-outline-variant/35 p-4">
              <div className="mb-2 flex items-center gap-2">
                <span className="material-symbols-outlined text-secondary">document_scanner</span>
                <h3 className="font-headline text-sm font-semibold text-on-surface">Detected Text</h3>
              </div>

              {ocrText ? (
                <p className="whitespace-pre-wrap text-sm leading-6 text-on-surface-variant">{highlightedOcr}</p>
              ) : (
                <p className="text-sm text-on-surface-variant">Text will appear after analysis</p>
              )}
            </article>
          </div>
        </div>

        <button
          type="button"
          onClick={handleAnalyze}
          disabled={loading || !file}
          className="primary-gradient inline-flex w-full items-center justify-center gap-2 rounded-full px-6 py-4 font-headline text-sm font-semibold text-on-primary shadow-[0_10px_26px_rgba(27,109,36,0.3)] disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
        >
          {loading ? (
            <>
              <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-on-primary/50 border-t-on-primary" />
              Analyzing...
            </>
          ) : (
            <>
              <span className="material-symbols-outlined text-base">analytics</span>
              Analyze Screenshot
            </>
          )}
        </button>

        {!hasResult ? (
          <div className="mt-6 flex items-center gap-3 rounded-lg border border-dashed border-outline-variant p-4 opacity-60">
            <span className="material-symbols-outlined text-on-surface-variant">hourglass_empty</span>
            <p className="text-sm text-on-surface-variant">Awaiting Analysis</p>
          </div>
        ) : null}
      </section>

      <BottomNav active="scanner" />
    </main>
  )
}
