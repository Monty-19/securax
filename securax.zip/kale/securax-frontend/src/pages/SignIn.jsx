import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { useNavigate } from 'react-router-dom'

export default function SignIn() {
  const navigate = useNavigate()
  const [showPassword, setShowPassword] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm()

  const onSubmit = async () => {
    localStorage.setItem('securax_seen', 'true')
    navigate('/dashboard')
  }

  const handleGoogleSignIn = () => {
    localStorage.setItem('securax_seen', 'true')
    navigate('/dashboard')
  }

  return (
    <main className="min-h-screen bg-[#f5faff] px-5 pb-10">
      <header className="flex flex-col items-center pt-12">
        <div className="flex items-center gap-2">
          <span
            className="material-symbols-outlined text-[34px] leading-none text-primary"
            style={{ fontVariationSettings: "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 48" }}
          >
            security
          </span>
          <p className="text-3xl font-bold text-on-surface" style={{ fontFamily: 'Manrope, sans-serif' }}>
            SecuraX
          </p>
        </div>
      </header>

      <form
        onSubmit={handleSubmit(onSubmit)}
        className="mx-auto mt-10 w-full max-w-[400px] rounded-lg bg-white p-8 shadow-[0_4px_40px_rgba(15,29,37,0.06)]"
      >
        <h1 className="text-[1.75rem] font-bold text-on-surface" style={{ fontFamily: 'Manrope, sans-serif' }}>
          Welcome back
        </h1>
        <p className="mt-2 text-base font-normal text-[#3f4a3c]">Sign in to your Guardian account</p>

        <div className="mt-7">
          <div className="relative">
            <span className="material-symbols-outlined pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[22px] text-[#3f4a3c]">
              mail
            </span>
            <input
              type="email"
              placeholder="Email"
              className="w-full rounded-full bg-[#e9f5ff] py-4 pl-12 pr-6 text-sm outline-none ring-0 transition focus:ring-2 focus:ring-primary"
              {...register('email', {
                required: 'Email is required',
                pattern: {
                  value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
                  message: 'Enter a valid email address',
                },
              })}
            />
          </div>
          {errors.email ? <p className="mt-1.5 text-xs text-[#ba1a1a]">{errors.email.message}</p> : null}
        </div>

        <div className="mt-4">
          <div className="relative">
            <span className="material-symbols-outlined pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-[22px] text-[#3f4a3c]">
              lock
            </span>
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              className="w-full rounded-full bg-[#e9f5ff] py-4 pl-12 pr-14 text-sm outline-none ring-0 transition focus:ring-2 focus:ring-primary"
              {...register('password', {
                required: 'Password is required',
                minLength: {
                  value: 6,
                  message: 'Password must be at least 6 characters',
                },
              })}
            />
            <button
              type="button"
              onClick={() => setShowPassword((value) => !value)}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#3f4a3c]"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              <span className="material-symbols-outlined text-[22px]">
                {showPassword ? 'visibility_off' : 'visibility'}
              </span>
            </button>
          </div>
          {errors.password ? <p className="mt-1.5 text-xs text-[#ba1a1a]">{errors.password.message}</p> : null}
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="primary-gradient mt-6 w-full rounded-full py-4 text-base font-semibold text-white shadow-[0_10px_24px_rgba(27,109,36,0.28)] disabled:opacity-60"
          style={{ fontFamily: 'Manrope, sans-serif' }}
        >
          {isSubmitting ? 'Signing In...' : 'Sign In'}
        </button>

        <div className="mt-6 flex items-center gap-3">
          <div className="h-px flex-1 bg-outline-variant" />
          <span className="text-xs text-[#3f4a3c]">or continue with</span>
          <div className="h-px flex-1 bg-outline-variant" />
        </div>

        <button
          type="button"
          onClick={handleGoogleSignIn}
          className="mt-5 flex w-full items-center justify-center gap-3 rounded-full border border-outline-variant/80 bg-white py-4 text-sm font-medium text-on-surface"
        >
          <svg aria-hidden="true" width="18" height="18" viewBox="0 0 48 48">
            <path
              fill="#FFC107"
              d="M43.611 20.083H42V20H24v8h11.303C33.655 32.657 29.231 36 24 36c-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.959 3.041l5.657-5.657C34.046 6.053 29.272 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"
            />
            <path
              fill="#FF3D00"
              d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.959 3.041l5.657-5.657C34.046 6.053 29.272 4 24 4c-7.682 0-14.344 4.337-17.694 10.691z"
            />
            <path
              fill="#4CAF50"
              d="M24 44c5.17 0 9.86-1.977 13.409-5.193l-6.19-5.238C29.146 35.091 26.677 36 24 36c-5.211 0-9.623-3.316-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"
            />
            <path
              fill="#1976D2"
              d="M43.611 20.083H42V20H24v8h11.303a12.05 12.05 0 01-4.087 5.569c.001-.001.002-.001.003-.002l6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"
            />
          </svg>
          Continue with Google
        </button>

        <p className="mt-6 text-center text-sm text-[#3f4a3c]">
          New here? <span className="font-semibold text-primary">Create account</span>
        </p>
      </form>
    </main>
  )
}
