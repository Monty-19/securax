import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useNavigate } from 'react-router-dom'

const features = [
  {
    icon: 'radar',
    title: 'Real-Time Scanning',
    subtitle: 'URLs, messages & screenshots',
  },
  {
    icon: 'shield_lock',
    title: 'AI-Powered Detection',
    subtitle: 'Gemini AI finds threats humans miss',
  },
  {
    icon: 'history',
    title: 'Full Threat History',
    subtitle: 'Every scan logged and reviewed',
  },
]

export default function Splash() {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [ready, setReady] = useState(false)

  useEffect(() => {
    const hasSeenOnboarding = localStorage.getItem('securax_seen')

    if (hasSeenOnboarding) {
      navigate('/dashboard', { replace: true })
      return
    }

    setReady(true)
  }, [navigate])

  useEffect(() => {
    if (!ready || step !== 1) {
      return
    }

    const timer = window.setTimeout(() => {
      setStep(2)
    }, 1800)

    return () => window.clearTimeout(timer)
  }, [ready, step])

  const handleGetStarted = () => {
    localStorage.setItem('securax_seen', '1')
    navigate('/signin')
  }

  if (!ready) {
    return null
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#f5faff] px-6">
      <AnimatePresence mode="wait">
        {step === 1 ? (
          <motion.section
            key="step-1"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="mx-auto flex min-h-screen w-full max-w-md flex-col items-center justify-center text-center"
          >
            <motion.span
              className="material-symbols-outlined text-[80px] leading-none text-[#1b6d24]"
              style={{ fontVariationSettings: "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 48" }}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.45, ease: [0.2, 0.9, 0.3, 1] }}
            >
              security
            </motion.span>

            <motion.h1
              className="mt-5 text-[2.5rem] font-bold leading-tight text-[#0f1d25]"
              style={{ fontFamily: 'Manrope, sans-serif', fontWeight: 700 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.12 }}
            >
              SecuraX
            </motion.h1>
            <motion.p
              className="mt-2 text-base text-[#3f4a3c]"
              style={{ fontFamily: 'Inter, sans-serif', fontWeight: 400 }}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.38, delay: 0.2 }}
            >
              Your Ethereal Guardian
            </motion.p>
          </motion.section>
        ) : (
          <motion.section
            key="step-2"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.35, ease: 'easeOut' }}
            className="mx-auto flex min-h-screen w-full max-w-md flex-col pb-10 pt-14"
          >
            <h2 className="text-center text-3xl font-bold text-[#0f1d25]" style={{ fontFamily: 'Manrope, sans-serif' }}>
              Welcome to SecuraX
            </h2>
            <p className="mt-2 text-center text-sm text-[#3f4a3c]">Smart protection, always on.</p>

            <div className="mt-10 space-y-4">
              {features.map((feature, index) => (
                <motion.article
                  key={feature.title}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.35, delay: 0.15 + index * 0.1 }}
                  className="glass-panel flex items-start gap-4 rounded-lg border border-[#becab9]/45 p-4"
                >
                  <span className="material-symbols-outlined mt-0.5 text-3xl leading-none text-[#005faf]">{feature.icon}</span>
                  <div>
                    <h3 className="text-base font-semibold text-[#0f1d25]" style={{ fontFamily: 'Manrope, sans-serif' }}>
                      {feature.title}
                    </h3>
                    <p className="mt-1 text-sm text-[#3f4a3c]">{feature.subtitle}</p>
                  </div>
                </motion.article>
              ))}
            </div>

            <motion.button
              type="button"
              onClick={handleGetStarted}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.55 }}
              className="primary-gradient mt-auto w-full rounded-lg px-4 py-3 font-semibold text-white"
            >
              Get Started
            </motion.button>
          </motion.section>
        )}
      </AnimatePresence>
    </main>
  )
}
