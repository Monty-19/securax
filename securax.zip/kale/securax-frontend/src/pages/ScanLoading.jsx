import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'sonner'
import { useScan } from '../hooks/useScan'

const subtitles = [
  'Checking domain reputation...',
  'Scanning for phishing patterns...',
  'Running AI classification...',
  'Verifying sender identity...',
]

export default function ScanLoading() {
  const location = useLocation()
  const navigate = useNavigate()
  const scanType = location.state?.scan_type || 'url'
  const inputValue = location.state?.input_value || ''
  const promiseKey = location.state?.scanPromise || ''
  const { scan } = useScan(scanType)
  const [subtitleIndex, setSubtitleIndex] = useState(0)
  const [dotIndex, setDotIndex] = useState(0)

  const subtitle = useMemo(() => subtitles[subtitleIndex], [subtitleIndex])

  useEffect(() => {
    const subtitleTimer = window.setInterval(() => {
      setSubtitleIndex((prev) => (prev + 1) % subtitles.length)
    }, 1200)

    const dotTimer = window.setInterval(() => {
      setDotIndex((prev) => (prev + 1) % 3)
    }, 400)

    return () => {
      window.clearInterval(subtitleTimer)
      window.clearInterval(dotTimer)
    }
  }, [])

  useEffect(() => {
    let active = true
    if (!inputValue) {
      navigate(-1)
      return () => {
        active = false
      }
    }

    scan(inputValue)
      .then((result) => {
        if (!active) return

        if (promiseKey) {
          sessionStorage.setItem(
            promiseKey,
            JSON.stringify({
              status: 'resolved',
              input_value: inputValue,
              scan_type: scanType,
              result,
            }),
          )
        }

        navigate('/scan/result', { state: result, replace: true })
      })
      .catch(() => {
        if (!active) return
        toast.error('Scan failed. Please try again.')
        navigate(-1)
      })

    return () => {
      active = false
    }
  }, [inputValue, navigate, promiseKey, scan, scanType])

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f5faff] px-6">
      <style>
        {`@keyframes blobMorph {
            0% { border-radius: 60% 40% 70% 30% / 50% 60% 40% 50%; }
            33% { border-radius: 40% 60% 35% 65% / 60% 45% 55% 40%; }
            66% { border-radius: 70% 30% 55% 45% / 35% 65% 35% 65%; }
            100% { border-radius: 60% 40% 70% 30% / 50% 60% 40% 50%; }
          }
          @keyframes orbRotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
          }
          @keyframes ringRotateReverse {
            from { transform: rotate(360deg); }
            to { transform: rotate(0deg); }
          }
          .securax-blob {
            width: 160px;
            height: 160px;
            background: linear-gradient(135deg, #1b6d24, #5dac5b);
            animation: blobMorph 3s ease-in-out infinite, orbRotate 8s linear infinite;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .securax-outer-ring {
            width: 200px;
            height: 200px;
            border: 2px dashed #5dac5b;
            border-radius: 50%;
            animation: ringRotateReverse 12s linear infinite;
          }`}
      </style>

      <section className="flex w-full max-w-md flex-col items-center gap-8 text-center">
        <div className="relative flex h-[200px] w-[200px] items-center justify-center">
          <div className="securax-outer-ring" />
          <div className="securax-blob absolute">
            <span
              className="material-symbols-outlined text-[56px] leading-none text-white"
              style={{ fontVariationSettings: "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 48" }}
            >
              radar
            </span>
          </div>
        </div>

        <div className="flex flex-col items-center gap-3">
          <h1 className="font-headline text-xl font-bold text-[#0f1d25]">Analyzing threat vectors...</h1>

          <AnimatePresence mode="wait">
            <motion.p
              key={subtitle}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
              className="text-sm text-on-surface-variant"
            >
              {subtitle}
            </motion.p>
          </AnimatePresence>
        </div>

        <div className="flex items-center gap-2">
          {[0, 1, 2].map((index) => (
            <motion.span
              key={index}
              className={`h-2.5 w-2.5 rounded-full ${dotIndex === index ? 'bg-primary' : 'bg-primary/25'}`}
              animate={{ scale: dotIndex === index ? 1.35 : 1 }}
              transition={{ duration: 0.2, ease: 'easeOut' }}
            />
          ))}
        </div>
      </section>
    </main>
  )
}
