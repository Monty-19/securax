import { useMemo, useRef, useState } from 'react'
import { motion } from 'framer-motion'
import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { toast } from 'sonner'
import BottomNav from '../components/BottomNav'
import { useHistory } from '../hooks/useHistory'
import api from '../lib/api'

const RING_CIRCUMFERENCE = 283

function getTimeAgo(value) {
  if (!value) {
    return 'Just now'
  }

  const timestamp = new Date(value)
  if (Number.isNaN(timestamp.getTime())) {
    return 'Just now'
  }

  const diffMs = Date.now() - timestamp.getTime()
  const mins = Math.floor(diffMs / 60000)
  if (mins < 1) return 'Just now'
  if (mins < 60) return `${mins}m ago`

  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`

  const days = Math.floor(hrs / 24)
  return `${days}d ago`
}

export default function Dashboard() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [inputValue, setInputValue] = useState('')
  const [isScanning, setIsScanning] = useState(false)
  const [scanType, setScanType] = useState(searchParams.get('type') === 'text' ? 'text' : 'url')
  const inputRef = useRef(null)

  const { scans, isLoading } = useHistory()

  const { data: stats } = useQuery({
    queryKey: ['history-stats'],
    queryFn: async () => {
      const { data } = await api.get('/api/history/stats')
      return data
    },
    retry: 1,
  })

  const historyItems = useMemo(() => scans, [scans])

  const recentItems = useMemo(() => historyItems.slice(0, 3), [historyItems])

  const threatsBlockedToday = useMemo(() => {
    const value = Number(stats?.threats_today)
    return Number.isFinite(value) ? value : 0
  }, [stats])

  const securityScore = useMemo(() => {
    const score = 100 - threatsBlockedToday * 5
    return Math.max(50, score)
  }, [threatsBlockedToday])

  const targetDashOffset = RING_CIRCUMFERENCE - (securityScore / 100) * RING_CIRCUMFERENCE

  const handleScan = async (value, type = 'url') => {
    const trimmed = value.trim()
    if (!trimmed) {
      toast.error(type === 'text' ? 'Enter a suspicious message to scan.' : 'Enter a URL to scan.')
      return
    }

    setIsScanning(true)
    const promiseKey = `securax_scan_${Date.now()}`
    sessionStorage.setItem(
      promiseKey,
      JSON.stringify({ status: 'pending', input_value: trimmed, scan_type: type }),
    )

    navigate('/scan/loading', {
      state: {
        scanPromise: promiseKey,
        input_value: trimmed,
        scan_type: type,
      },
    })

    setIsScanning(false)
  }

  return (
    <main className="min-h-screen bg-surface">
      <header className="glass-nav fixed inset-x-0 top-0 z-40 border-b border-outline-variant/40 px-4 py-3">
        <div className="mx-auto flex w-full max-w-7xl items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-full bg-primary text-sm font-bold text-on-primary">G</div>
            <div>
              <p className="font-headline text-base font-bold text-on-surface">Guardian Pro</p>
              <div className="mt-0.5 flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-primary" />
                <p className="text-xs font-medium text-primary">Device Safe</p>
              </div>
            </div>
          </div>
          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-primary"
            aria-label="Verified guardian status"
          >
            <span className="material-symbols-outlined">verified_user</span>
          </button>
        </div>
      </header>

      <section className="mx-auto flex w-full max-w-7xl flex-col gap-8 px-4 pb-24 pt-20 md:px-6">
        <div className="flex flex-col gap-4 md:flex-row">
          <article className="glass-panel flex flex-1 flex-col rounded-xl border border-outline-variant/40 p-5 md:p-6">
            <h1 className="font-headline text-3xl font-extrabold text-on-surface">Analyze Threat</h1>
            <p className="mt-1.5 text-sm text-on-surface-variant">Paste any URL or suspicious message.</p>

            <div className="mt-5 flex flex-col gap-3 sm:flex-row">
              <div className="relative flex-1">
                <span className="material-symbols-outlined pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-on-surface-variant">
                  search
                </span>
                <input
                  ref={inputRef}
                  type="text"
                  value={inputValue}
                  onChange={(event) => setInputValue(event.target.value)}
                  placeholder={scanType === 'text' ? 'Paste suspicious message here...' : 'https://example.com'}
                  className="w-full rounded-full border-none bg-surface-container-low py-3.5 pl-12 pr-4 text-sm text-on-surface outline-none transition focus:bg-surface-container-highest focus:ring-2 focus:ring-primary"
                />
              </div>

              <button
                type="button"
                onClick={() => handleScan(inputValue, scanType)}
                disabled={isScanning}
                className="primary-gradient inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold text-on-primary shadow-[0_8px_26px_rgba(27,109,36,0.3)] disabled:opacity-65"
              >
                <span className="material-symbols-outlined text-lg">radar</span>
                {isScanning ? 'Scanning...' : 'Scan Now'}
              </button>
            </div>
          </article>

          <article className="glass-panel w-full rounded-xl border border-outline-variant/40 p-5 md:w-80">
            <h2 className="font-headline text-lg font-semibold text-on-surface">Security Score</h2>

            <div className="relative mx-auto mt-4 h-32 w-32">
              <svg viewBox="0 0 100 100" className="h-full w-full -rotate-90">
                <circle cx="50" cy="50" r="45" stroke="#d6e5ef" strokeWidth="8" fill="transparent" />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="45"
                  stroke="#1b6d24"
                  strokeWidth="8"
                  fill="transparent"
                  strokeLinecap="round"
                  strokeDasharray={RING_CIRCUMFERENCE}
                  initial={{ strokeDashoffset: RING_CIRCUMFERENCE }}
                  animate={{ strokeDashoffset: targetDashOffset }}
                  transition={{ duration: 1, ease: 'easeOut' }}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <p className="font-headline text-4xl font-extrabold text-on-surface">{securityScore}</p>
                <p className="text-xs font-semibold text-primary">Good</p>
              </div>
            </div>

            <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary/12 px-3 py-2 text-xs font-semibold text-primary">
              <span className="material-symbols-outlined text-base">shield</span>
              {threatsBlockedToday} Threats blocked today
            </div>
          </article>
        </div>

        <section>
          <h2 className="font-headline text-lg font-semibold text-on-surface">Quick Actions</h2>
          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <button
              type="button"
              onClick={() => {
                setScanType('text')
                navigate('/dashboard?type=text')
              }}
              className="glass-panel flex items-center gap-3 rounded-lg border border-outline-variant/40 p-4 text-left"
            >
              <span className="material-symbols-outlined rounded-full bg-secondary/15 p-2 text-secondary">mail</span>
              <div>
                <p className="font-headline text-sm font-semibold">Scan Email</p>
                <p className="text-xs text-on-surface-variant">Analyze suspicious content</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => {
                setScanType('url')
                inputRef.current?.focus()
              }}
              className="glass-panel flex items-center gap-3 rounded-lg border border-outline-variant/40 p-4 text-left"
            >
              <span className="material-symbols-outlined rounded-full bg-primary/15 p-2 text-primary">link</span>
              <div>
                <p className="font-headline text-sm font-semibold">Scan URL</p>
                <p className="text-xs text-on-surface-variant">Paste and verify links</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => navigate('/scan/screenshot')}
              className="glass-panel flex items-center gap-3 rounded-lg border border-outline-variant/40 p-4 text-left"
            >
              <span className="material-symbols-outlined rounded-full bg-tertiary/15 p-2 text-tertiary">image</span>
              <div>
                <p className="font-headline text-sm font-semibold">Scan Image</p>
                <p className="text-xs text-on-surface-variant">Upload suspicious screenshots</p>
              </div>
            </button>
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-headline text-lg font-semibold text-on-surface">Recent Activity</h2>
            <Link to="/history" className="text-sm font-semibold text-primary">
              View All
            </Link>
          </div>

          {isLoading ? (
            <div className="mt-3 space-y-3">
              {[1, 2, 3].map((row) => (
                <div key={row} className="h-16 animate-pulse rounded-xl bg-surface-container-low" />
              ))}
            </div>
          ) : null}

          {!isLoading && recentItems.length ? (
            <div className="mt-3 space-y-3">
              {recentItems.map((item, index) => {
                const threat = Boolean(item?.is_threat)
                const icon = threat ? 'warning' : 'check_circle'
                const iconColor = threat ? 'text-error' : 'text-tertiary'
                const badgeClass = threat
                  ? 'bg-error-container text-on-error-container'
                  : 'bg-tertiary-container text-on-tertiary-container'
                const label = item?.input_value || `Scan #${index + 1}`

                return (
                  <article
                    key={item?.id ?? `${label}-${index}`}
                    className="glass-panel flex items-center justify-between gap-3 rounded-lg border border-outline-variant/40 p-4"
                  >
                    <div className="flex min-w-0 items-center gap-3">
                      <span className={`material-symbols-outlined ${iconColor}`}>{icon}</span>
                      <div className="min-w-0">
                        <p className="truncate text-sm font-semibold text-on-surface">{label}</p>
                        <p className="text-xs text-on-surface-variant">{getTimeAgo(item?.created_at)}</p>
                      </div>
                    </div>

                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${badgeClass}`}>
                      {threat ? 'Threat Blocked' : 'Safe'}
                    </span>
                  </article>
                )
              })}
            </div>
          ) : null}

          {!isLoading && !recentItems.length ? (
            <div className="mt-3 rounded-lg border border-dashed border-outline-variant bg-surface-container-low p-5 text-sm text-on-surface-variant">
              No scans yet. Try scanning a URL above.
            </div>
          ) : null}
        </section>
      </section>

      <BottomNav active="shield" />
    </main>
  )
}
