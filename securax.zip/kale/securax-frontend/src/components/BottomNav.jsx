import { NavLink } from 'react-router-dom'

const navItems = [
  { key: 'shield', to: '/dashboard', icon: 'security', label: 'Shield' },
  { key: 'scanner', to: '/scan/screenshot', icon: 'document_scanner', label: 'Scanner' },
  { key: 'history', to: '/history', icon: 'history', label: 'History' },
  { key: 'settings', to: '/settings', icon: 'settings', label: 'Settings' },
]

export default function BottomNav({ active }) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-outline-variant/35 bg-[#f5faff]/80 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 shadow-[0_-8px_24px_rgba(15,29,37,0.08)] backdrop-blur-2xl md:hidden">
      <ul className="mx-auto flex w-full max-w-md items-center justify-between rounded-t-[2rem]">
        {navItems.map((item) => (
          <li key={item.to}>
            <NavLink to={item.to}>
              {({ isActive }) => {
                const selected = active
                  ? active === item.key || (active === 'scan' && item.key === 'scanner')
                  : isActive

                return (
                  <span
                    className={`inline-flex flex-col items-center justify-center gap-1 px-3 py-2 text-xs transition ${
                      selected
                        ? 'rounded-full bg-tertiary-container/20 px-5 text-primary'
                        : 'text-on-surface/50 hover:text-primary'
                    }`}
                  >
                    <span
                      className="material-symbols-outlined text-[1.1rem] leading-none"
                      style={{
                        fontVariationSettings:
                          item.key === 'shield' && selected
                            ? "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 24"
                            : "'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24",
                      }}
                    >
                      {item.icon}
                    </span>
                    {item.label}
                  </span>
                )
              }}
            </NavLink>
          </li>
        ))}
      </ul>
    </nav>
  )
}
