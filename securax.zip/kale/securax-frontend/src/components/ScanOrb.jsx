export default function ScanOrb({ state = 'idle', size = 160, animated = false }) {
  const iconSize = `${Math.max(20, Math.round(size / 2.8))}px`

  const stateConfig = {
    idle: {
      gradient: 'linear-gradient(135deg, #1b6d24, #5dac5b)',
      icon: 'radar',
      shadow: '0 10px 40px rgba(27,109,36,0.25)',
    },
    threat: {
      gradient: 'linear-gradient(135deg, #ba1a1a, #ffdad6)',
      icon: 'warning',
      shadow: '0 10px 40px rgba(186,26,26,0.22)',
    },
    safe: {
      gradient: 'linear-gradient(135deg, #006e1c, #4caf50)',
      icon: 'check_circle',
      shadow: '0 10px 40px rgba(0,110,28,0.24)',
    },
  }

  const current = stateConfig[state] ?? stateConfig.idle

  return (
    <div className="relative inline-flex items-center justify-center">
      <style>
        {`@keyframes securaxOrbMorph {
          0% { border-radius: 60% 40% 70% 30% / 50% 60% 40% 50%; }
          33% { border-radius: 40% 60% 35% 65% / 60% 45% 55% 40%; }
          66% { border-radius: 70% 30% 55% 45% / 35% 65% 35% 65%; }
          100% { border-radius: 60% 40% 70% 30% / 50% 60% 40% 50%; }
        }`}
      </style>
      <div
        className="flex items-center justify-center"
        style={{
          width: `${size}px`,
          height: `${size}px`,
          background: current.gradient,
          borderRadius: '60% 40% 70% 30% / 50% 60% 40% 50%',
          boxShadow: current.shadow,
          animation: animated ? 'securaxOrbMorph 3s ease-in-out infinite' : 'none',
        }}
      >
        <span
          className="material-symbols-outlined leading-none text-white"
          style={{
            fontSize: iconSize,
            fontVariationSettings: "'FILL' 1, 'wght' 400, 'GRAD' 0, 'opsz' 48",
          }}
        >
          {current.icon}
        </span>
      </div>
    </div>
  )
}
