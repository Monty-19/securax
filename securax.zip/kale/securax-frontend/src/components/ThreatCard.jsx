export default function ThreatCard({ title, risk, detail }) {
  const riskStyles = {
    Low: 'bg-tertiary-container text-on-tertiary-container',
    Medium: 'bg-secondary-container text-on-surface',
    High: 'bg-error-container text-on-error-container',
  }

  return (
    <article className="glass-panel rounded-lg border border-outline-variant/40 p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h3 className="font-headline text-lg font-semibold text-on-surface">{title}</h3>
        <span
          className={`rounded-full px-3 py-1 text-xs font-semibold ${riskStyles[risk] ?? 'bg-surface-container text-on-surface-variant'}`}
        >
          {risk}
        </span>
      </div>
      <p className="text-sm leading-6 text-on-surface-variant">{detail}</p>
    </article>
  )
}
