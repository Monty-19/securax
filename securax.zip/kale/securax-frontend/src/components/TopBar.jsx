import { useNavigate } from 'react-router-dom'

export default function TopBar({ title, showBack = false, onBack, rightIcon }) {
  const navigate = useNavigate()

  const handleBack = () => {
    if (onBack) {
      onBack()
      return
    }
    navigate(-1)
  }

  return (
    <header className="fixed inset-x-0 top-0 z-40 h-16 border-b border-outline-variant/35 bg-[#f5faff]/80 shadow-sm backdrop-blur-xl">
      <div className="mx-auto flex h-full w-full max-w-7xl items-center justify-between px-4">
        {showBack ? (
          <button
            type="button"
            onClick={handleBack}
            className="flex h-10 w-10 items-center justify-center rounded-full bg-surface-container text-on-surface"
            aria-label="Go back"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
        ) : (
          <div className="h-10 w-10" />
        )}

        <h1 className="font-headline text-lg font-bold text-on-surface">{title}</h1>

        {rightIcon ? <div className="flex h-10 w-10 items-center justify-center">{rightIcon}</div> : <div className="h-10 w-10" />}
      </div>
    </header>
  )
}
