import { Component } from 'react'

class ErrorBoundary extends Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false }
  }

  static getDerivedStateFromError() {
    return { hasError: true }
  }

  componentDidCatch(error) {
    // eslint-disable-next-line no-console
    console.error('Unhandled UI error:', error)
  }

  handleGoHome = () => {
    window.location.href = '/'
  }

  render() {
    if (this.state.hasError) {
      return (
        <main className="flex min-h-screen items-center justify-center bg-surface px-6">
          <section className="glass-panel w-full max-w-md rounded-xl border border-outline-variant/35 p-8 text-center">
            <h1 className="font-headline text-3xl font-bold text-on-surface">Something went wrong</h1>
            <p className="mt-3 text-sm text-on-surface-variant">
              The app hit an unexpected issue. You can safely return to the home screen.
            </p>
            <button
              type="button"
              onClick={this.handleGoHome}
              className="primary-gradient mt-6 inline-flex items-center justify-center rounded-full px-6 py-3 font-semibold text-on-primary"
            >
              Go Home
            </button>
          </section>
        </main>
      )
    }

    return this.props.children
  }
}

export default ErrorBoundary
