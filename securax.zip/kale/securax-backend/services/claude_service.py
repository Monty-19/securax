import json
import os

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

model = genai.GenerativeModel(
    model_name="gemini-2.0-flash",
    generation_config=genai.GenerationConfig(
        response_mime_type="application/json",
        temperature=0.1,
        max_output_tokens=1024,
    ),
    system_instruction="""
You are SecuraX, an expert cybersecurity AI specializing in phishing detection.
Analyze the provided text and determine if it is a phishing attempt, social engineering attack, or malicious content.

You MUST respond ONLY with a valid JSON object matching this exact schema:
{
  "is_threat": boolean,
  "confidence_score": number between 0 and 100,
  "threat_type": string or null (e.g. "Credential Phishing", "Smishing", "Business Email Compromise", "Malware Link", null),
  "reasons": array of strings (each a specific red flag found, empty array if safe),
  "summary": string (one sentence explaining the verdict)
}

Red flags to detect:
- Suspicious or typosquatted domains (paypa1.com, b4nk-login.com, apple-secure-id.net)
- Urgency or fear language ("Your account will be suspended", "Act now", "Verify immediately")
- Mismatched sender identity or display name spoofing
- Requests for credentials, OTPs, card numbers, or personal data
- Shortened or obfuscated URLs (bit.ly, tinyurl, etc.)
- Generic impersonal greetings ("Dear Customer", "Dear User")
- Grammar and spelling inconsistencies typical of phishing templates
- Unsolicited attachments or download links
- Impersonation of known brands (Apple, Google, PayPal, banks)

If the content is clearly safe, return is_threat: false with an empty reasons array.
""",
)


async def classify_threat(text: str, context: str = "") -> dict:
    try:
        prompt = f"Analyze this for phishing:\n\n{text}"
        if context:
            prompt += f"\n\nAdditional context: {context}"

        response = await model.generate_content_async(prompt)
        result = json.loads(response.text)

        required = ["is_threat", "confidence_score", "threat_type", "reasons", "summary"]
        for key in required:
            if key not in result:
                raise ValueError(f"Missing key: {key}")

        return result

    except Exception as e:
        return {
            "is_threat": False,
            "confidence_score": 50,
            "threat_type": None,
            "reasons": ["Analysis incomplete — treat with caution"],
            "summary": f"Gemini analysis failed: {str(e)}",
        }
