import io
import re

import pytesseract
from PIL import Image, ImageEnhance


async def extract_text_from_image(image_bytes: bytes) -> str:
    try:
        with Image.open(io.BytesIO(image_bytes)) as img:
            if img.mode != "RGB":
                img = img.convert("RGB")

            width, height = img.size
            if width < 800:
                img = img.resize((width * 2, height * 2), Image.Resampling.LANCZOS)

            img = ImageEnhance.Contrast(img).enhance(1.4)
            raw_text = pytesseract.image_to_string(img, config="--psm 6")

        cleaned = raw_text.replace("\x00", "")
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned.strip()
    except Exception:
        return ""


def find_suspicious_patterns(text: str) -> list[str]:
    if not text:
        return []

    patterns = [
        r"https?://[^\s]+",
        r"\b(?:bit\.ly|tinyurl\.com|t\.co|goo\.gl)/[^\s]+",
        r"\b(?:verify|suspend|click\s+here|act\s+now|otp|password)\b",
    ]

    matches = []
    for pattern in patterns:
        matches.extend(re.findall(pattern, text, flags=re.IGNORECASE))

    seen = set()
    deduped = []
    for match in matches:
        key = match.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(match)

    return deduped
