import asyncio
import os

import httpx
from dotenv import load_dotenv

load_dotenv()

FALLBACK_RESULT = {
    "malicious_count": 0,
    "suspicious_count": 0,
    "harmless_count": 0,
    "total_engines": 0,
    "is_flagged": False,
    "vt_summary": "VirusTotal scan unavailable",
}


async def check_url(url: str) -> dict:
    api_key = os.getenv("VIRUSTOTAL_API_KEY", "")
    if not api_key:
        return FALLBACK_RESULT.copy()

    headers = {"x-apikey": api_key}
    post_endpoint = "https://www.virustotal.com/api/v3/urls"

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            post_response = await client.post(
                post_endpoint,
                headers=headers,
                data={"url": url},
            )
            post_response.raise_for_status()

            post_payload = post_response.json()
            analysis_id = (
                post_payload.get("data", {}).get("id")
                or post_payload.get("data", {}).get("attributes", {}).get("id")
            )
            if not analysis_id:
                return FALLBACK_RESULT.copy()

            status = "queued"
            analysis_payload = {}

            for attempt in range(3):
                get_response = await client.get(
                    f"https://www.virustotal.com/api/v3/analyses/{analysis_id}",
                    headers=headers,
                )
                get_response.raise_for_status()
                analysis_payload = get_response.json()
                status = (
                    analysis_payload.get("data", {})
                    .get("attributes", {})
                    .get("status", "queued")
                )

                if status == "completed":
                    break

                if attempt < 2:
                    await asyncio.sleep(1)

            stats = (
                analysis_payload.get("data", {})
                .get("attributes", {})
                .get("stats", {})
            )

            malicious_count = int(stats.get("malicious", 0) or 0)
            suspicious_count = int(stats.get("suspicious", 0) or 0)
            harmless_count = int(stats.get("harmless", 0) or 0)
            undetected_count = int(stats.get("undetected", 0) or 0)

            total_engines = malicious_count + suspicious_count + harmless_count + undetected_count
            flagged_count = malicious_count + suspicious_count
            is_flagged = malicious_count > 0 or suspicious_count > 2

            return {
                "malicious_count": malicious_count,
                "suspicious_count": suspicious_count,
                "harmless_count": harmless_count,
                "total_engines": total_engines,
                "is_flagged": is_flagged,
                "vt_summary": f"{flagged_count}/{total_engines} engines flagged this URL"
                if total_engines > 0
                else "VirusTotal scan unavailable",
            }
    except Exception:
        return FALLBACK_RESULT.copy()
