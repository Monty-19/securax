import json
from datetime import datetime

from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlmodel import Session, delete, func, select

from database import get_session
from models.scan_models import ScanResult

router = APIRouter(tags=['history'])


class ScanHistoryItem(BaseModel):
    id: int
    scan_type: str
    input_value: str
    is_threat: bool
    confidence_score: float
    threat_type: str | None
    reasons: list[str]
    created_at: datetime


def _parse_reasons(value: str | None) -> list[str]:
    if not value:
        return []
    try:
        parsed = json.loads(value)
        if isinstance(parsed, list):
            return [str(item) for item in parsed if item is not None]
        return []
    except Exception:
        return []


@router.get('/history')
def get_scan_history(
    limit: int = 20,
    session: Session = Depends(get_session),
) -> list[ScanHistoryItem]:
    query_limit = max(1, limit)
    rows = session.exec(
        select(ScanResult)
        .order_by(ScanResult.created_at.desc())
        .limit(query_limit)
    ).all()

    return [
        ScanHistoryItem(
            id=row.id or 0,
            scan_type=row.scan_type.value if hasattr(row.scan_type, 'value') else str(row.scan_type),
            input_value=row.input_value,
            is_threat=row.is_threat,
            confidence_score=row.confidence_score,
            threat_type=row.threat_type,
            reasons=_parse_reasons(row.reasons),
            created_at=row.created_at,
        )
        for row in rows
    ]


@router.get('/history/stats')
def get_history_stats(session: Session = Depends(get_session)) -> dict:
    total_scans = session.exec(select(func.count()).select_from(ScanResult)).one() or 0
    threats_blocked = session.exec(
        select(func.count()).select_from(ScanResult).where(ScanResult.is_threat.is_(True))
    ).one() or 0
    safe_scans = int(total_scans) - int(threats_blocked)

    today_midnight_utc = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    threats_today = session.exec(
        select(func.count())
        .select_from(ScanResult)
        .where(ScanResult.is_threat.is_(True))
        .where(ScanResult.created_at >= today_midnight_utc)
    ).one() or 0

    return {
        'total_scans': int(total_scans),
        'threats_blocked': int(threats_blocked),
        'safe_scans': int(safe_scans),
        'threats_today': int(threats_today),
    }


@router.delete('/history/{scan_id}')
def delete_scan(scan_id: int, session: Session = Depends(get_session)) -> dict:
    row = session.get(ScanResult, scan_id)
    if row:
        session.delete(row)
        session.commit()
    return {'deleted': True}


@router.delete('/history')
def clear_history(session: Session = Depends(get_session)) -> dict:
    all_rows = session.exec(select(ScanResult)).all()
    deleted_count = len(all_rows)
    session.exec(delete(ScanResult))
    session.commit()
    return {'deleted': deleted_count}
