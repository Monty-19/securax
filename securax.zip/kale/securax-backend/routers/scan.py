import json

from fastapi import APIRouter, Depends, File, UploadFile
from sqlmodel import Session

from database import get_session
from models.scan_models import ScanRequest, ScanResponse, ScanResult, ScanType
from services import classify_threat
from services.ocr_service import extract_text_from_image, find_suspicious_patterns
from services.virustotal_service import check_url

router = APIRouter(tags=['scan'])


def _persist_scan(
    session: Session,
    *,
    scan_type: ScanType,
    input_value: str,
    result: ScanResponse,
) -> None:
    scan_row = ScanResult(
        scan_type=scan_type,
        input_value=input_value,
        is_threat=result.is_threat,
        confidence_score=result.confidence_score,
        threat_type=result.threat_type,
        reasons=json.dumps(result.reasons),
        ocr_text=result.ocr_text,
    )
    session.add(scan_row)
    session.commit()


@router.post('/url', response_model=ScanResponse)
async def scan_url(
    payload: ScanRequest,
    session: Session = Depends(get_session),
) -> ScanResponse:
    vt_result = await check_url(payload.input_value)
    context = f"VirusTotal: {vt_result['vt_summary']}"
    ai_result = await classify_threat(payload.input_value, context)

    confidence_score = float(ai_result.get('confidence_score', 0))
    if vt_result.get('is_flagged') and confidence_score < 70:
        confidence_score = min(99, confidence_score + 15)
        ai_result['confidence_score'] = confidence_score

        if not ai_result.get('is_threat'):
            ai_result['is_threat'] = True
            reasons = ai_result.get('reasons', [])
            if not isinstance(reasons, list):
                reasons = []
            reasons.append('Flagged by VirusTotal threat database')
            ai_result['reasons'] = reasons

    response = ScanResponse(
        is_threat=bool(ai_result.get('is_threat')),
        confidence_score=float(ai_result.get('confidence_score', 0)),
        threat_type=ai_result.get('threat_type'),
        reasons=[str(item) for item in ai_result.get('reasons', [])],
        ocr_text=None,
    )

    _persist_scan(
        session,
        scan_type=ScanType.URL,
        input_value=payload.input_value,
        result=response,
    )

    return response


@router.post('/text', response_model=ScanResponse)
async def scan_text(
    payload: ScanRequest,
    session: Session = Depends(get_session),
) -> ScanResponse:
    ai_result = await classify_threat(payload.input_value)

    response = ScanResponse(
        is_threat=bool(ai_result.get('is_threat')),
        confidence_score=float(ai_result.get('confidence_score', 0)),
        threat_type=ai_result.get('threat_type'),
        reasons=[str(item) for item in ai_result.get('reasons', [])],
        ocr_text=None,
    )

    _persist_scan(
        session,
        scan_type=ScanType.TEXT,
        input_value=payload.input_value,
        result=response,
    )

    return response


@router.post('/screenshot', response_model=ScanResponse)
async def scan_screenshot(
    file: UploadFile = File(...),
    session: Session = Depends(get_session),
) -> ScanResponse:
    input_label = file.filename or 'uploaded_image'

    image_bytes = await file.read()
    ocr_text = await extract_text_from_image(image_bytes)
    if not ocr_text:
        response = ScanResponse(
            is_threat=False,
            confidence_score=0,
            threat_type=None,
            reasons=['Could not extract text from image'],
            ocr_text='',
        )

        _persist_scan(
            session,
            scan_type=ScanType.SCREENSHOT,
            input_value=input_label,
            result=response,
        )

        return response

    suspicious = find_suspicious_patterns(ocr_text)
    context = f'Extracted from screenshot. Suspicious patterns found: {suspicious}'
    ai_result = await classify_threat(ocr_text, context)

    response = ScanResponse(
        is_threat=bool(ai_result.get('is_threat')),
        confidence_score=float(ai_result.get('confidence_score', 0)),
        threat_type=ai_result.get('threat_type'),
        reasons=[str(item) for item in ai_result.get('reasons', [])],
        ocr_text=ocr_text,
    )

    _persist_scan(
        session,
        scan_type=ScanType.SCREENSHOT,
        input_value=input_label,
        result=response,
    )

    return response
