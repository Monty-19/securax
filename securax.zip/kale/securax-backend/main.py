from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import create_db_and_tables
from routers import history, scan

load_dotenv()

app = FastAPI(title='SecuraX API')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['http://localhost:5173'],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)


@app.on_event('startup')
def on_startup() -> None:
    create_db_and_tables()


@app.get('/')
def health_check() -> dict:
    return {'status': 'ok', 'app': 'SecuraX API'}


app.include_router(scan.router, prefix='/api/scan')
app.include_router(history.router, prefix='/api')
