from datetime import datetime
from enum import Enum

from pydantic import BaseModel
from sqlalchemy import Column, Text
from sqlmodel import Field, SQLModel


class ScanType(str, Enum):
    URL = 'URL'
    TEXT = 'TEXT'
    SCREENSHOT = 'SCREENSHOT'


class ScanResult(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    scan_type: ScanType
    input_value: str
    is_threat: bool
    confidence_score: float
    threat_type: str | None = None
    reasons: str = Field(default='[]', sa_column=Column(Text, nullable=False))
    ocr_text: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ScanRequest(BaseModel):
    input_value: str


class ScanResponse(BaseModel):
    is_threat: bool
    confidence_score: float
    threat_type: str | None
    reasons: list[str]
    ocr_text: str | None
